// Single Family Rental Market Research Report Generator
// JavaScript functionality for handling form submission and report generation

document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const form = document.getElementById('reportForm');
    const queryInput = document.getElementById('queryInput');
    const generateBtn = document.getElementById('generateBtn');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const errorAlert = document.getElementById('errorAlert');
    const errorMessage = document.getElementById('errorMessage');
    const resultsSection = document.getElementById('resultsSection');
    const reportOutput = document.getElementById('reportOutput');
    const routeBadge = document.getElementById('routeBadge');
    const queryDisplay = document.getElementById('queryDisplay');

    // Form submission handler
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const query = queryInput.value.trim();
        
        if (!query) {
            showError('Please enter a query to generate a report.');
            return;
        }

        // Reset UI state
        hideError();
        hideResults();
        showLoading();
        disableForm();

        try {
            // Send request to Flask backend
            const response = await fetch('/generate_report', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: query
                })
            });

            const data = await response.json();

            if (data.success) {
                // Display successful report
                displayReport(data.report, data.route, data.query);
            } else {
                // Display error message
                showError(data.error || 'Failed to generate report. Please try again.');
            }

        } catch (error) {
            console.error('Error:', error);
            showError('Network error. Please check your connection and try again.');
        } finally {
            hideLoading();
            enableForm();
        }
    });

    // Auto-resize textarea
    queryInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // Utility functions
    function showLoading() {
        loadingIndicator.style.display = 'block';
    }

    function hideLoading() {
        loadingIndicator.style.display = 'none';
    }

    function showError(message) {
        errorMessage.textContent = message;
        errorAlert.style.display = 'block';
        // Scroll to error
        errorAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function hideError() {
        errorAlert.style.display = 'none';
    }

    function showResults() {
        resultsSection.style.display = 'block';
        // Scroll to results
        setTimeout(() => {
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
    }

    function hideResults() {
        resultsSection.style.display = 'none';
    }

    function disableForm() {
        generateBtn.disabled = true;
        queryInput.disabled = true;
        generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
    }

    function enableForm() {
        generateBtn.disabled = false;
        queryInput.disabled = false;
        generateBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Generate Report';
    }

    function displayReport(report, route, query) {
        // Set route badge
        routeBadge.textContent = route;
        routeBadge.className = `badge bg-${getRouteBadgeColor(route)}`;
        
        // Set query display
        queryDisplay.textContent = query;
        
        // Set report content
        reportOutput.textContent = report;
        
        // Add generated class for styling
        reportOutput.parentElement.classList.add('report-generated');
        
        // Show results section
        showResults();
        
        // Log success
        console.log('Report generated successfully:', {
            route: route,
            query: query,
            reportLength: report.length
        });
    }

    function getRouteBadgeColor(route) {
        const colors = {
            'region': 'primary',
            'city': 'info', 
            'neighbourhood': 'success'
        };
        return colors[route] || 'secondary';
    }

    // Add some example queries on click
    const exampleQueries = [
        'Tampa, Florida rental market analysis',
        'US Southeast region single family rental trends',
        'Upper East Side, New York neighborhood rental market',
        'Austin, Texas metro area investment opportunities',
        'California statewide rental market overview',
        '78704 zip code rental analysis'
    ];

    // Add click handlers for example text
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('example-query')) {
            queryInput.value = e.target.textContent;
            queryInput.focus();
        }
    });
});

// Add keyboard shortcut for quick generation (Ctrl/Cmd + Enter)
document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('reportForm').dispatchEvent(new Event('submit'));
    }
});

// Add error reporting for debugging
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
});