# SFR_research_scope_router.py
# Single Family Rental Research Scope Router

import os
from openai import OpenAI

class SFRResearchRouter:
    """
    Routes user input to appropriate research scope and generates reports using OpenAI Responses API.
    
    Flow:
    1. Classify input as REGION, CITY, or NEIGHBORHOOD 
    2. Call corresponding saved prompt
    3. Return the output text
    """
    
    def __init__(self, api_key: str = None):
        self.client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))
        
        # Saved prompt IDs for each scope
        self.prompts = {
            'REGION': 'pmpt_68b327b5c68481909f2f2290ebb39fbc0052abaea202cb8a',
            'CITY': 'pmpt_68b3243fd794819785fb7c3aea2d6eb001490f812f28790f', 
            'NEIGHBORHOOD': 'pmpt_68b334e8fe388197b1092140185a6c3609ea05d6949558e2'
        }
    
    def classify_scope(self, user_input: str) -> str:
        """
        Determine research scope based on user input.
        Returns: REGION, CITY, or NEIGHBORHOOD
        """
        # Handle empty input - default to REGION
        if not user_input or user_input.strip() == "":
            return 'REGION'
            
        # Use OpenAI to classify the input
        classification_prompt = """
        Classify this location input into one of three categories:

        REGION: USA, US regions (Midwest, East Coast, South, etc.), or US states (California, Texas, etc.)
        CITY: US cities or metropolitan areas (Cleveland, Tampa, Miami, etc.)  
        NEIGHBORHOOD: Neighborhoods or districts within cities (Wesley Chapel in Tampa, Manhattan in New York, etc.)

        Default to REGION if uncertain.

        Input: {input}
        
        Respond with only one word: REGION, CITY, or NEIGHBORHOOD
        """.format(input=user_input)
        
        try:
            response = self.client.responses.create(
                model="gpt-4o-mini",
                instructions=classification_prompt,
                input=user_input
            )
            
            # Extract response text
            result = response.output_text.strip().upper()
            
            # Validate result
            if result in ['REGION', 'CITY', 'NEIGHBORHOOD']:
                return result
            else:
                return 'REGION'  # Default fallback
                
        except Exception as e:
            print(f"Classification error: {e}")
            return 'REGION'  # Default fallback
    
    def generate_report(self, scope: str, user_input: str) -> str:
        """
        Generate report using saved prompt for the given scope.
        """
        prompt_id = self.prompts[scope]
        
        try:
            response = self.client.responses.create(
                model="gpt-4.1", 
                prompt={
                    "id": prompt_id,
                    "variables": {"user_query": user_input}
                },
                input=user_input
            )
            
            return response.output_text
            
        except Exception as e:
            return f"Error generating {scope} report: {str(e)}"
    
    def route_and_generate(self, user_input: str) -> dict:
        """
        Main method: Classify input and generate appropriate report.
        
        Returns:
        {
            'scope': 'REGION|CITY|NEIGHBORHOOD',
            'prompt_id': 'pmpt_xxx...',
            'output': 'Generated report text'
        }
        """
        # Step 1: Classify scope
        scope = self.classify_scope(user_input)
        
        # Step 2: Generate report using saved prompt
        output = self.generate_report(scope, user_input)
        
        return {
            'scope': scope,
            'prompt_id': self.prompts[scope],
            'output': output
        }


# For backward compatibility with existing Flask app
class RoutingClient:
    """Wrapper to maintain compatibility with existing Flask integration."""
    
    def __init__(self, api_key: str = None):
        self.router = SFRResearchRouter(api_key or os.environ.get("OPENAI_API_KEY"))
    
    def route_and_run(self, user_query: str, **kwargs) -> dict:
        """
        Compatible method for existing Flask app.
        """
        result = self.router.route_and_generate(user_query)
        
        # Map to expected format
        return {
            'route': result['scope'].lower(),
            'prompt_id': result['prompt_id'], 
            'output_text': result['output']
        }