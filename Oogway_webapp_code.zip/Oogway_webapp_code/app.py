import os
import logging
from flask import Flask, render_template, request, jsonify
from routing_client import RoutingClient

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Initialize the routing client
routing_client = RoutingClient()

@app.route('/')
def index():
    """Render the main page with the market research form."""
    return render_template('index.html')

@app.route('/generate_report', methods=['POST'])
def generate_report():
    """
    Process the user query and generate a market research report.
    Returns JSON response with the report or error message.
    """
    try:
        # Get the user query from the form
        data = request.get_json() or {}
        user_query = data.get('query', '').strip()
        
        if not user_query:
            return jsonify({
                'success': False,
                'error': 'Please enter a query to generate a report.'
            }), 400
        
        # Log the query for debugging
        app.logger.info(f"Processing query: {user_query}")
        
        # Use the routing client to process the query and generate report
        result = routing_client.route_and_run(
            user_query=user_query,
            return_meta=True
        )
        
        # Extract the report content
        report_content = result.get('output_text', '')
        route = result.get('route', 'unknown')
        
        if not report_content:
            return jsonify({
                'success': False,
                'error': 'Failed to generate report. Please try again with a different query.'
            }), 500
        
        app.logger.info(f"Generated report for route: {route}")
        
        return jsonify({
            'success': True,
            'report': report_content,
            'route': route,
            'query': user_query
        })
        
    except Exception as e:
        app.logger.error(f"Error generating report: {str(e)}")
        return jsonify({
            'success': False,
            'error': f'An error occurred while generating the report: {str(e)}'
        }), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    app.logger.error(f"Internal server error: {str(error)}")
    return jsonify({
        'success': False,
        'error': 'Internal server error. Please try again later.'
    }), 500

if __name__ == '__main__':
    # Run the Flask app on port 5000, binding to all interfaces
    app.run(host='0.0.0.0', port=5000, debug=True)